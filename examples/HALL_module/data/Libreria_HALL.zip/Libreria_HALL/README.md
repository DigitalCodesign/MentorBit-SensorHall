# MentorBitHALL

Librería para la lectura de datos de distancias utilizando el sensor HALL en módulos compatibles con MentorBit.

## Descripción

La librería `MentorBitHALL` facilita la detección de imanes permanetes desde el sensor HALL en módulos compatibles con MentorBit. Permite obtener mediciones precisas para aplicaciones de control de distancias y sistemas de automatización.

## Modo de Empleo

1.  **Instalación:**
    * Abre el IDE compatible con MentorBit.
    * Ve a "Herramientas" -> "Gestionar librerías..."
    * Busca "MentorBitHALL" e instálala.
    * **Nota:**

2.  **Ejemplo básico:**

    ```c++
    #include <MentorbitHALL.h>

    // Crear una instancia de la clase con los pines correspondientes
    // HallPin en 2, LED en 13
    HallLed hallSensor(2, 13);

    void setup() {
    // Inicializa los pines y la librería
        hallSensor.begin();
        Serial.begin(9600);
    }

    void loop() {
    // Actualiza el estado del sensor y del LED
        hallSensor.update();

    // Opcional: imprimir en serie el estado del sensor
        if (digitalRead(2)) {
            Serial.println("Sensor Hall activado");
        } else {
            Serial.println("Sensor Hall desactivado");
        }

        delay(100); // Pequeña pausa para estabilidad
    }
    ```

## Constructor y Métodos Públicos

### Constructor

* `MentorBit_VL53()`: Crea un objeto `MentorBit_VL53`.

### Métodos

* `void begin()`: Inicializa el sensor VL53.
* `float leerDistancia()`: Lee la distancia en mm.
